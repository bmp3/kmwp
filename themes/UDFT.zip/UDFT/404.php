<?php

get_header(); ?>
<h1 style="text-align:center;">404, no such page</h1>
<?php /*get_sidebar();*/  ?>
<?php get_footer(); ?>