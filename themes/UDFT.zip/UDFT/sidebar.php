<?php
/**
* Чистый Шаблон для разработки
* Шаблон сайдбара, все виджеты добавляйте из админки
* @package WordPress
* @subpackage clean
*/

?>
<?php dynamic_sidebar(); ?>