<?php

/**
 * Header Form Template
 */

global $post;

echo do_shortcode( '[kmwp_get_content_form class="header-form green"]');

?>